package Lesson5;

public class AbsoluteDiff {
	

}
