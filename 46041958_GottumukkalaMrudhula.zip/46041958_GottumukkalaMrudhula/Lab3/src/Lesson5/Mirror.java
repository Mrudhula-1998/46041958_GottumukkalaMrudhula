package Lesson5;

public class Mirror {
	public static void main(String[] args) {  
        StringBuffer sb = new StringBuffer("programming");  
        System.out.println(sb+" | "+sb.reverse()); 
  
    }  

}
