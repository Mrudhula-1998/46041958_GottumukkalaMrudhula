import java.util.*;
public class trafficlight {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("enter your choice");
		String s=sc.nextLine();
		
		switch(s) {
		case "red":
			System.out.println("Stop");
			break;
		case "yellow":
			System.out.println("ready");
			break;
		case "green":
			System.out.println("go");
			break;
		}
	}

}
