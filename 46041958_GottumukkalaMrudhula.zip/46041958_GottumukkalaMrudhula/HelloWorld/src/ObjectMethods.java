
public class ObjectMethods {
	public static void main(String args[]) {
	ObjectMethods objectmethods=new ObjectMethods();
 
	}

}
