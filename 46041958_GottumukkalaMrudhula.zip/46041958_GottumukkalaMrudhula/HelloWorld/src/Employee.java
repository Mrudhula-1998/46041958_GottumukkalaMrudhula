import java.util.Scanner;
public class Employee {
	String name;
	int id;
	float salary;
	int batchno;
	public void getdetails() {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the name - ");
		name=sc.next();
		System.out.print("Enter the id - ");
		id=sc.nextInt();
		System.out.print("Enter the salary - ");
		salary=sc.nextFloat();
		System.out.print("Enter the batchno - ");
		batchno=sc.nextInt();
	}
	public void display() {
		System.out.println("name = "+name);
		System.out.println("id = "+id);
		System.out.println("salary = "+salary);
		System.out.println("batchno = "+batchno);
	}
	public static void main(String[] args) {
		Employee emp=new Employee();
		emp.getdetails();
		emp.display();
	}
}
