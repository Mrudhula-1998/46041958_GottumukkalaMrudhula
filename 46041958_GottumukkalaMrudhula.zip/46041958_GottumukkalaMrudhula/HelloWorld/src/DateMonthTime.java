import java.util.Date;

public class DateMonthTime {

	public static void main(String[] args) {
		Date date=new Date();
		System.out.println("Todays Date : "+date.getDate());
		System.out.println("Todays Day : "+date.getDay());
		System.out.println("Todays Year : "+date.getYear());
		System.out.println("Todays Month : "+date.getMonth());

	}

}
