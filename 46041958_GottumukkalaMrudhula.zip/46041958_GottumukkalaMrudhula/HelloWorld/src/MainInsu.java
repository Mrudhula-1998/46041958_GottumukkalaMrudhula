import java.util.*;
public class MainInsu {
	public static void main(String args[]) {
		
		Insurance insurance =new Insurance();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Entere the policy no ");
		int policy_No=sc.nextInt();
		insurance.setPolicy_No(policy_No);
		 
		 System.out.println("Enter the contact no ");
		 int contact_no=sc.nextInt();
		 insurance.setContact_no(contact_no);
		 
		 System.out.println("Enter the type of insurance ");
		 String typeofInsurance=sc.next();
		 insurance.setTypeofInsurance(typeofInsurance);
		 
		 sc.close();
		 System.out.println(insurance); 
		  
				
	}

}
