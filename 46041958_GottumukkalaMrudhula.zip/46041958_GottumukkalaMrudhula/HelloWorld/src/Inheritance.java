
public class Inheritance {
	
		
		   public static void main(String[] args) {

		      Dance dance1 = new Dance();

		      dance1.eat();
		      dance1.sleep();

		    dance1.dance();
		   }
		}


