
public class Currentsec {

	public static void main(String[] args) {
		
		      // returns the current time in milliseconds
		      System.out.print("Current Time in milliseconds = ");
		      System.out.println(System.currentTimeMillis());
		   

	}

}
