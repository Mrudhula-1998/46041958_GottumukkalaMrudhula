
public class Dance extends Inherit {
	
		   public void dance() {
		      System.out.println("I can dance");
		   }
}
