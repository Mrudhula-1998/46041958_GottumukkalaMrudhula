
public class Employee1 {
	int empno=20;
	float empsalary=2000;
	String name="Mrudhula";
	
	int displayempno() {
		return empno;
	}
	float displayempsalary() {
		return empsalary;
	}
	String displayname() {
		return name;
	}
	public static void main(String[] args) {
		Employee1 imp=new Employee1();
		
		int result=imp.displayempno();
		 float result1=imp.displayempsalary();
		String result3= imp.displayname();
		System.out.println(result);
		System.out.println(result1);
		System.out.println(result3);
	}
}
