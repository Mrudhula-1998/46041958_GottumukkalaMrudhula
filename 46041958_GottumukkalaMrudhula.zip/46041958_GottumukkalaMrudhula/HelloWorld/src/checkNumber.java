import java.util.*;
public class checkNumber {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	System.out.print("Enter the number - " );
		int n=sc.nextInt();
		if(n%2==0){
		System.out.println(n+" is power of 2");
		}
		else
			System.out.println("Not power");
	}

}
