
public class Box {
	double height=1;
	double width=2;
	double length=3;
	
	double calculateVolume() {
		return height*width*length;
	}
	public static void main(String args[]) {
		Box b=new Box();
		double answer=b.calculateVolume();
		System.out.println(answer);
	}
}
