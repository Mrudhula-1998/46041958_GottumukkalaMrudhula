import java.util.Scanner;
import java.util.*;
public class sumofcubes {
	public static void main(String args[]) {
		int sum=0;
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter first number- ");
	int a=sc.nextInt();
	for(int i=1;i<a;i++) {
		sum=sum+(i*i*i);
	}
	System.out.println(sum);
	}
}
