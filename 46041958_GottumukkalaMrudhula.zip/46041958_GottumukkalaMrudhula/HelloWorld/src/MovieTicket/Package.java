package MovieTicket;

public class Package {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int no1=10;
		int no2=20;
		System.out.println(no1+no2);

	}

}
