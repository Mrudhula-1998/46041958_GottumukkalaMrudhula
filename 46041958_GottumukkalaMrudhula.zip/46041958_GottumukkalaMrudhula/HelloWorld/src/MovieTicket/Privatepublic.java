package MovieTicket;
class Task{
	private int number=7;
	public int add()
	{
		int number1=10;
		int sum=number+number1;
		return sum;
	}
}
public class Privatepublic {
	public static void main(String args[]) {
		Task task=new Task();
		int result=task.add();
		System.out.println(result);
	}

}
