package MovieTicket;
public class Product {
	Product(){
		this(123,"Powder",55);
	}
	Product(int id,String name,float cost){
		System.out.println("Info : ");
		System.out.println("Product id :"+id);
		System.out.println("Product name :"+name);
		System.out.println("Product cost :"+cost);
		
	}
	public static void main(String[] args) {
		Product product=new Product();
		Product product1=new Product(456,"Maggie",20);
	
	}
	

}
