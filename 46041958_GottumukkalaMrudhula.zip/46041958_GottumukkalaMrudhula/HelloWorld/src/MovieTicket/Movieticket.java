package MovieTicket;

public class Movieticket {
	
		private String  movieName;
		private float ticketCost;
		private int noOfSeats;
		
		public String toString()
		{
			return "Movie name: "+getmovieName()+" \nTicket cost: "+getticketCost()+" \nTotal No Of seats:  "+getnoOfSeats();
		}
		public String getmovieName()
		{
			return movieName;
		}
		public void setmovieName(String movieName)
		{
			this.movieName = movieName;
		}
		public float getticketCost()
		{
			return ticketCost;
		}
		public void setticketCost(float ticketCost)
		{
			this.ticketCost = ticketCost;
		}
		public int getnoOfSeats()
		{
			return noOfSeats;
		}
		public void setnoOfSeats(int noOfSeats)
		{
			this.noOfSeats = noOfSeats;
		}
	}


