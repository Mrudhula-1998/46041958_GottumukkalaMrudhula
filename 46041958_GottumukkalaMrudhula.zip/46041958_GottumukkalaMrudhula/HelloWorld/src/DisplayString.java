import java.util.*;
public class DisplayString {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter your name : ");
		String name=sc.nextLine();
		
		System.out.println("The length of the string is "+name.length());
		
		System.out.println("calling name is  "+name.substring(9,15));
		
		if(name==null)
			System.out.println("No name found");
		else
			System.out.println("Name found");
	}

	}


