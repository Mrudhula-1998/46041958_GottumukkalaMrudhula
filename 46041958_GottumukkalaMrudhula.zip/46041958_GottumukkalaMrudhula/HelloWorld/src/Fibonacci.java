import java.util.*;
public class Fibonacci {

	public static void main(String[] args) {
		int a=0,b=1,c;

		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the number-");
		int n=sc.nextInt();
		System.out.print(a+" "+b);
		for(int i=2;i<n;++i) {
			
			c=a+b;
			System.out.println(" "+c);
			a=b;
			b=c;
			
		}
		
		
	}
	

}
