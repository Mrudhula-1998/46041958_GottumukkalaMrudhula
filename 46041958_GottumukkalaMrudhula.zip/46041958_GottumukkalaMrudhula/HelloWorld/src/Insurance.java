
public class Insurance {
	int policy_No;
	String typeofInsurance;
	int contact_no;
	public String toString() {
		return(getPolicy_No()+" "+ getContact_no() +" "+getTypeofInsurance());
	}
	public int getPolicy_No() {
		return policy_No;
	}
	public void setPolicy_No(int policy_No) {
		this.policy_No = policy_No;
	} 
	public String getTypeofInsurance() {
		return typeofInsurance;
	}
	public void setTypeofInsurance(String typeofInsurance) {
		this.typeofInsurance = typeofInsurance;
	}
	public int getContact_no() {
		return contact_no;
	}
	public void setContact_no(int contact_no) {
		this.contact_no = contact_no;
	}
	

}
