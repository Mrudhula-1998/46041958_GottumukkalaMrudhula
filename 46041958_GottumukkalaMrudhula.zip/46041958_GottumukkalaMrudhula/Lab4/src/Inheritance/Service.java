package Inheritance;

import java.util.Scanner;

public class Service extends Employee implements EmployeeService {

	int id;
	float sal;
	String name,desg;
	Employee emp=new Employee();
	public static void main(String[] args)
	{
		Service s=new Service();
		s.getEmpDet();
		s.dispEmp();
	}

	@Override
	public void getEmpDet() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter empID");
		id=sc.nextInt();
		emp.setId(id);
		System.out.println("Enter name");
		name=sc.next();
		emp.setName(name);
		System.out.println("Enter designation");
		desg=sc.next();
		emp.setDesignation(desg);
		System.out.println("Enter salary");
		sal=sc.nextFloat();
		emp.setSalary(sal);
		sc.close();
	}

	@Override
	public String insScheme(float sal) {
		// TODO Auto-generated method stub
		if(sal>=20000.0f)
			return "Grade 1 insurance scheme";
		else if(sal>20000.0f && sal<=50000.0f)
			return "Grade 2 insurance scheme";
		else
			return "High grade insurance scheme";
	}

	@Override
	public void dispEmp() {
		// TODO Auto-generated method stub
		System.out.println("Name of employee is "+emp.getName());
		System.out.println("Employee ID is "+emp.getId());
		System.out.println("Employee Designation is "+emp.getDesignation());
		System.out.println("Employee Salary is "+emp.getSalary());
		System.out.println("Employee is eligible for "+insScheme(sal));
	}

}
