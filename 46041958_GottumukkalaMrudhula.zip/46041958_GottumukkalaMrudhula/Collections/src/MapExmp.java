import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapExmp {

	public static void main(String[] args) {
		Map map=new HashMap();
		map.put("First", "1st");
		map.put("2nd", new Float(2.0f));
		map.put("third", "3rd");
		
		//Duplicate elements overrides the previous assignment
		map.put("third", 3);
		
		Set set=map.keySet();//to view the map
		Collection collection=map.values();//return collection view of values
		Set mapset=map.entrySet();
		System.out.println(set+"\n"+collection+"\n"+mapset);
		
		

	}

}
