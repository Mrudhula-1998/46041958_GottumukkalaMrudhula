import java.util.HashSet;
import java.util.Set;

public class SetExmp {
	
	public static void main(String args[]) 
	{
		
		Set set=new HashSet();// cretaing obj for set
		
		// adading elements in list
		set.add("first");
		set.add("second");
		set.add("third");
		set.add("4th");
		set.add(new Float(4.0f));
		set.add(new Integer(5));
		// it will be automatically wrapped into object in java 5
		set.add(7);
		
		System.out.println(set);

}
}
