import java.util.Stack;

public class StackDemo {

	public static void main(String[] args) {
		
		Stack<Integer> stack=new Stack<Integer>();
		
		System.out.println("The stack elements are "+stack);
		System.out.println("IS empty "+stack.isEmpty());
		
		stack.push(1);
		stack.push(2);
		stack.push(3);
		stack.push(4);
		System.out.println("The stack elements are "+stack);
		System.out.println("Pop operation "+stack.pop());
		System.out.println("The stack elements are "+stack);
		System.out.println("The search operation "+stack.search(2));
		System.out.println("The stack elements are "+stack);
		System.out.println("The stack elements are "+stack);
		System.out.println("The peek operation: "+stack.peek());
		System.out.println("IS empty "+stack.isEmpty());
		

	}

}
