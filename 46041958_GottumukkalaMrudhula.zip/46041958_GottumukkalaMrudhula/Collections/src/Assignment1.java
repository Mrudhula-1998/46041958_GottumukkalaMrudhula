
public class Assignment1 {
	 
		public void color() throws NullPointerException
		   {
		       System.out.println("Blue");
		   }  
		}

		class Room extends Assignment1
		{
		  public void color() 
		   {
		       System.out.println("White");
		   }  
		   public static void main(String args[]) 
		   {  
			   Assignment1 obj = new Room();  
		       obj.color(); 
		   } 
		   
		   
		
	 
}
