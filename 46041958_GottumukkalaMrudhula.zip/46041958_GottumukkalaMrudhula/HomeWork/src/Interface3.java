
public class Interface3 {
	public static void main(String[] args) {
		Interface1 obj=new Interface2();
		obj.assignment1();
		obj.assignment2();
	}

}
