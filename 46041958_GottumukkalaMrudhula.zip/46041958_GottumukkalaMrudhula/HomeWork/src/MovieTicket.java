
	import java.util.*;
public class Detailmain 
{
	public static void main(String args[])
	{
		Movieticket mt = new Movieticket();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the movie name :");
		String name = sc.nextLine();
		mt.setmovieName(name);
		System.out.println("enter the Ticket cost :");
		float cost = sc.nextFloat();
		mt.setticketCost(cost);
		System.out.println("enter the total available seats :");
		int total = sc.nextInt();
		mt.setnoOfSeats(total);
		System.out.println(mt);
		sc.close();
	}
}