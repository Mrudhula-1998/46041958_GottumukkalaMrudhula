// Animal main class


public class MainAnimal {

	public static void main(String[] args) {
		Animal obj=new Dog();
		obj.sound();

	}

}
