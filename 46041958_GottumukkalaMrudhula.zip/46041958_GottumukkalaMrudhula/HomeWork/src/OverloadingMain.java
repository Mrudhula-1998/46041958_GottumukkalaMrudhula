
public class OverloadingMain {

	public static void main(String[] args) {
		System.out.println(Method.add(10, 10));
		System.out.println(Method.add(10,10,10));

	}

}
