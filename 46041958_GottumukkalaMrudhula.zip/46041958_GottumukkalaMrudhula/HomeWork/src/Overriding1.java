
public class Overriding1 extends Overriding {
	public void eat(){
	      System.out.println("Boy is eating");
	   }

}
