// Dog class


public class Dog extends Animal{
	public void sound() {
		System.out.println("Buffaloe");
	}

}
