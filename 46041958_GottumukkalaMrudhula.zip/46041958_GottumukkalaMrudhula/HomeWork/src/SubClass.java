
public class SubClass extends SuperClass {
	int varSub=30;
	int mtdSub=20;
	
	int varResult1;
	
	public void sub() {
		
	//super.add();
		varResult1= varSub-mtdSub;
		System.out.println("The subtraction of numbers is "+varResult1);
	}


}
