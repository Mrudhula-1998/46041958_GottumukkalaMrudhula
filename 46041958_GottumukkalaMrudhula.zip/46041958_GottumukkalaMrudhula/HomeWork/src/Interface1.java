
 interface Interface1 {
	 public void assignment1();
	 public void assignment2();

}
