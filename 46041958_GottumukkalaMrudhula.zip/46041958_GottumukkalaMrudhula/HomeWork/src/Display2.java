
class Display2 extends Display {
	public void Disp2() {
		System.out.println("overiding method");
	}
	

}
