
class Interface2 implements Interface1 {
	public void assignment1() {
		System.out.println("Assignment1");
	}
	
	public void assignment2() {
		System.out.println("Assignment2");
	}
	

}
