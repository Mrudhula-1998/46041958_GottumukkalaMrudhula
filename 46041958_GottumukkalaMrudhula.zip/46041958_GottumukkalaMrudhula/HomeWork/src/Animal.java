// Animal parent class

abstract class Animal {
	public abstract  void sound();

}


