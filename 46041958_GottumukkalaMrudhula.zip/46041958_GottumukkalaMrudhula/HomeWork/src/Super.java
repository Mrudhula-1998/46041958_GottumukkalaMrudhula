
public class Super {

	public void Display() {
	System.out.println("Parent class");
	}
	class Sub extends Super {
		public void Display() {
			System.out.println("Child class");
		}
	}
		
		public static void main(String[] args) {
			Super obj=new Super();
			obj.Display();
			
			
		}
	
}
