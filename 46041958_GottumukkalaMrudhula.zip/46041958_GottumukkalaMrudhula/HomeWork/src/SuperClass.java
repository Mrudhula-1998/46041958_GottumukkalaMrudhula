
public class SuperClass {
	int varSuper=10;
	int mtdSuper=20;
	
	int varResult;
	
	public void add() {
		varResult= varSuper+mtdSuper;
		System.out.println("The addition of numbers is "+varResult);
	}

}
