
public class DisplayMain {

	public static void main(String[] args) {
		Display2 obj=new Display2();
		obj.Disp2();

	}

}
