
public class Overriding {
	public void eat()
	   {
	      System.out.println("Human is eating");
	   }

}
