
public class Speed{
	  public static void main(String args[]) {
		    int speed= 186000;
		    long days;
		    long seconds;
		    long distance;

		   

		    days = 1000; 

		    seconds = days * 24 * 60 * 60; 

		    distance = speed * seconds; 

		    System.out.print("no of days " + days);
		    System.out.print(" travel ");
		    System.out.println(distance + " miles.");
		  }
		}
