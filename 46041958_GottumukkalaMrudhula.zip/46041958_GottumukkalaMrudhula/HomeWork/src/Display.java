
abstract class Display {
	public void Disp() {
		System.out.println("parent class");
	}
	abstract public void Disp2();

}
