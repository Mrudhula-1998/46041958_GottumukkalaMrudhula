
public class SavingAccount extends Account {
	
	public void deposit(int number)
	{
		System.out.println("Deposited amount "+number);
	}
}
