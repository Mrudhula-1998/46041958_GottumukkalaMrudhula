import java.util.*;
public class User {
	
	
	public User(String Name,String City, int Salary) {
		System.out.println("Name of the user is "+Name);
		System.out.println("City is "+City);
		System.out.println("Salary is "+Salary);
		
	}
	
	public static void main(String args[]) {
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the name ");
	String Name=sc.nextLine();
	System.out.println("Enter the city ");
	String City=sc.nextLine();
	System.out.println("Enter the salary");
	int Salary=sc.nextInt();
	
	User display=new User(Name,City,Salary);

}
}
