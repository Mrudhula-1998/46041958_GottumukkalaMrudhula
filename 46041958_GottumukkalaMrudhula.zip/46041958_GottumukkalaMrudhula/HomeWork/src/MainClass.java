
public class MainClass {
	public static void main(String args[]) {
		SubClass obj=new SubClass();
		
		obj.sub();
		
	}

}
