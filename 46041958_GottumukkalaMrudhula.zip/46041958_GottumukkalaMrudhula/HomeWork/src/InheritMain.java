
public class InheritMain {
	public static void main(String[] args) {
		Account account=new Account();
		
		account.display();
		account.withDraw();
		
		SavingAccount sav=new SavingAccount();
		sav.deposit(1000);
		sav.display();
		sav.withDraw();
		
		
		CurrentAccount cur=new CurrentAccount();
		cur.deposit(1000);
		cur.display();
		cur.withDraw();
		cur.savings();
	}

}
