
public class OverridingMain {

	public static void main(String[] args) {
		Overriding obj = new Overriding();
	      //This will call the child class version of eat()
	      obj.eat();

	}

}
