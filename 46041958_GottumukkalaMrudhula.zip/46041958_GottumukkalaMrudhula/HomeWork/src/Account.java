
public class Account {
	
	public void withDraw() {
		System.out.println("Withdraw invoked");
	}
	
	public void display() {
		System.out.println("Display from super class");
	}

}
