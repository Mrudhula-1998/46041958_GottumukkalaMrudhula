
public class CurrentAccount extends SavingAccount{
	
	
	public void savings() {
		System.out.println("Savings amount is invoked");
			}

}
