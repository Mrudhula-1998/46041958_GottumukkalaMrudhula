// ALL DATA TYPES

package Lesson;

public class Demo5 {
	int number1;
	byte number2;
	short number3;
	float number4;
	String number5;
	boolean number6;
	long number7;
	char number8;
	
	public void Data() {
		System.out.println("Default value of int is "+number1);
		System.out.println("Default value of byte is "+number2);
		System.out.println("Default value of short is "+number3);
		System.out.println("Default value of float is "+number4);
		System.out.println("Default value of string is "+number5);
		System.out.println("Default value of boolean is "+number6);
		System.out.println("Default value of long is "+number7);
		System.out.println("Default value of char is "+number8);
	}
	
	public static void main(String[] args) {
		Demo5 demo5=new Demo5();
		demo5.Data();
	}
	

}
