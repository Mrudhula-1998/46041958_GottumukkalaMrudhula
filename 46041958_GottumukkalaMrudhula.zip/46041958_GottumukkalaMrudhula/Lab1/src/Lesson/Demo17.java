//RELATIONAL OPERATORS

package Lesson;

public class Demo17 {

	public static void main(String[] args) {
		int i=10;
		int j=6;
		 System.out.println("i is "+i);
		 System.out.println("j is "+j);
		 System.out.println("i>j is "+(i>j));
		 System.out.println("i>=j is "+(i>=j));
		 System.out.println("i<j is "+(i<j));
		 System.out.println("i<=j is "+(i<=j));
		 System.out.println("i==j is "+(i==j));
		 System.out.println("i!=j is "+(i!=j));
		 

	}

}
