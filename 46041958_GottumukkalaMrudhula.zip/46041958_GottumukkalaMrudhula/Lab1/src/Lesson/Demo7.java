//SCOPE OF A VARIABE

package Lesson;

public class Demo7 {
	public static void main(String[] args) {
		int globalvariable=10;
		{
			int localvariable=20;
			System.out.println(globalvariable);
			System.out.println(localvariable);
		}
		int localvariable=9;
		System.out.println(globalvariable);
		System.out.println(localvariable);
	}

}
