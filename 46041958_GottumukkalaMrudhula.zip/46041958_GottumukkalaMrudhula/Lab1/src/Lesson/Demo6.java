//CHARACTER DISPLAY

package Lesson;

public class Demo6 {
	public static void main(String args[]) {
	char c[]= {'a','B','1','b',' '};
	for(int i=0;i<c.length;i++)
	{
	if(Character.isDigit(c[i]))
		System.out.println(c[i]+ " It is a digit");
	
	if(Character.isLetter(c[i]))
		System.out.println(c[i]+ " It is a letter");
	
	if(Character.isUpperCase(c[i]))
		System.out.println(c[i]+ " It is a upper");
	
	if(Character.isLowerCase(c[i]))
		System.out.println(c[i]+ " It is a lower");
	
	if(Character.isWhitespace(c[i]))
		System.out.println(c[i]+ " It is a whitespace");
	

	}
}


}
