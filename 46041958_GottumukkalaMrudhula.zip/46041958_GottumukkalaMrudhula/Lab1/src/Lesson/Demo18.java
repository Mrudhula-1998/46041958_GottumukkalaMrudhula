//POSTFIX PREFIX EXPRESIONS

package Lesson;

public class Demo18 {

	public static void main(String[] args) {
		int num1=10,num2=4;
		int num3;
		
		num3=--num1+num2++;
		System.out.println(num1);
		System.out.println(num2);
		System.out.println(num3);

	}

}
