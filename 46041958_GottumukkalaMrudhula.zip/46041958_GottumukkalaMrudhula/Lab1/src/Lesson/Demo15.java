//ARTHEMETIC OPERATIONS

package Lesson;

public class Demo15 {

	public static void main(String[] args) {
		int a=20,b=10;
		
		System.out.println(" the addition is "+(a+b));
		
		System.out.println(" the subtraction is "+(a-b));
		
		System.out.println(" the multiplication is "+(a*b));
		
		System.out.println(" the division is "+(a/b));
		
		System.out.println(" the module is "+(a%b));
		
	}

}
