//USING STRING IN SWITCH

package Lesson;

public class Demo8 {

	public static void main(String[] args) {
		//String grade;
		 char issue='C';
			switch(issue) {

			case 'A': 
			System.out.println("super");
			break;
			case 'B': 
			System.out.println("Very good");
			break;
			case 'C': 
			System.out.println("good");
			break;
			case 'D': 
			System.out.println("average");
			break;
			case 'E':
			System.out.println("belowaverage");
			break;
			default:System.out.println("fail");
			break;

}

}
}





