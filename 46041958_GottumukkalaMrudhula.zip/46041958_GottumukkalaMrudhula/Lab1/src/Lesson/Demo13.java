//WHILE EXAMPLE

package Lesson;

public class Demo13 {

	public static void main(String[] args) {
		int number=0;
		while(number<10) {
			
			System.out.println(number+" is number");
			number++;
		}


	}

}
