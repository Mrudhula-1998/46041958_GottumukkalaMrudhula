//SWITCH EXAMPLE

package Lesson;
import java.util.*;
public class Demo10 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.print("Enter the a value ");
		int a=sc.nextInt();
		
		System.out.print("Enter the b value ");
		int b=sc.nextInt();
		
		System.out.println("Enter your choice");
		int choice=sc.nextInt();
		
		switch(choice)
		{
		case 1:   int c=a+b;
		  		  System.out.println(c);
		  		  break;
		case 2:   int d=a-b;
		          System.out.println(d);
		          break;
		case 3:   int e=a*b;
		          System.out.println(e);
		          break;
		case 4:   int f=a/b;
		          System.out.println(f);
		          break;
		default:  System.out.println("Invalid choice");
		          break;
		}
	}

	
}
