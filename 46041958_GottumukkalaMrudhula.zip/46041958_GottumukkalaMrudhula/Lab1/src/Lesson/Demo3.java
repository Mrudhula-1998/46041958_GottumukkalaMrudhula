//PROGRAM FOR DEBUGGING

package Lesson;

public class Demo3 {

	
		int number1,number2;
		
		public void test() {
		for(int i=0;i<10;i++) {
			System.out.println("value of i is "+i);
			System.out.println("value of number1 is "+number1);
			System.out.println("value of number2 is "+number2);
			i+=1;
			number1=number1+1;
			number2=number2+3;
		}
	}
		public static void main(String args[]) {
			Demo3 demo=new Demo3();
			demo.test();
		}
	}


