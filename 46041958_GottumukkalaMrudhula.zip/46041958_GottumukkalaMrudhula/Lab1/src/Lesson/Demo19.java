//TERINARY OPERATOR

package Lesson;

public class Demo19 {

	public static void main(String[] args) {
		int number=10;
		System.out.println(number==10?"True":"Flase");
		number++;
		System.out.println(number==10?"True":"Flase");
		

	}

}
