//DO WHILE EXAMPLE

package Lesson;

public class Demo12 {

	public static void main(String[] args) {
		int number=0;
		do {
			
			System.out.println(number+" is number");
			number++;
		}while(number<10);

	}

}
