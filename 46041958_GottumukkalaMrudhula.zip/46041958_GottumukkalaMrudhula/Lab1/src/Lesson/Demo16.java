// LEFT SHIFT

package Lesson;

public class Demo16 {

	public static void main(String[] args) {
		int num1=10;
		int i;
		for(i=0;i<4;i++) {
			num1=num1<<1;
			System.out.println(num1);
		}
		

	}

}
