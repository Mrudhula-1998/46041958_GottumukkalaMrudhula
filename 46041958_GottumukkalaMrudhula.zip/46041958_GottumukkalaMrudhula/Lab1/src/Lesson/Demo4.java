//TIPS FOR ECLIPSE

package Lesson;

public class Demo4 {
	private int number=10;
	private int number1;
	private int number2;
	
	public void display() {
		System.out.println("Data is "+number);
		}
	
	public static void main(String[] args) {
		Demo4 demo4=new Demo4();
		demo4.display();
	}

}
