//LABELLED BREAK

package Lesson;

public class Demo14 {

	public static void main(String[] args) {
		int n=10;
		int c=20;
		int k=0;
		stop:
			for(int i=1;i<n;i++) {
				for(int j=1;j<n;j++) {
					if(i==c) {
						break stop;
					}
					k=k+1;
				}
			}
		System.out.println(k);
		

	}

}
