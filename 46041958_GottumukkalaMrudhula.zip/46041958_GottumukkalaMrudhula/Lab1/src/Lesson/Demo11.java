//CONTINUE EXAMPLE

package Lesson;

public class Demo11 {

	public static void main(String[] args) {
		int number=10;
		int sum=0;
		for(int i=1;i<number;i++) {
			if(i%2==0) {
			
			continue;
			
		}
			sum=sum+i;
	}
		System.out.println(sum);

}
}
