//Validate the age of a person and display proper message by using user defined exception. Age of a person should be above 15.

class AgeException extends Exception
	{
	    public AgeException(String s)
	    {
	        // Call constructor of parent Exception
	        super(s);
	    }
	}
public class Ageexc{
	
		void age(int age) throws AgeException {
			if(age>15) {
				throw new AgeException("age valid");
			}
				else
					System.out.println("age invalid");
			
		}
		public static void main(String args[]) {
			Ageexc obj=new Ageexc();
			try {
				obj.age(10);
				
			}
			catch(AgeException e) {
				//System.out.println("exception");
				System.out.println(e.getMessage());
				
			}
		}
	
}
