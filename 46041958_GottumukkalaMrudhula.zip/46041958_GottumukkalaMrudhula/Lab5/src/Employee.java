//Create an Exception class named as �EmployeeException�(User defined Exception) in a package named as �com.cg.eis.exception� and 
//throw an exception if salary of an employee is below than 3000.Use Exception Handling mechanism to handle exception properly
class EmployeeException extends Exception
	{
	    public EmployeeException(String s)
	    {
	        super(s);
	    }
	}
public class Employee  {
	
	void salary(double d) throws EmployeeException {
		if(d<3000) {
			throw new EmployeeException("salary less than limit");
		}
		else System.out.println("salary is higher");
	}
	public static void main(String args[]) {
		Employee obj=new Employee();
		try {
			obj.salary(20000);

		}
		catch(EmployeeException e) {
			//System.out.println("exception");
			System.out.println(e.getMessage());
		}
	}


}
