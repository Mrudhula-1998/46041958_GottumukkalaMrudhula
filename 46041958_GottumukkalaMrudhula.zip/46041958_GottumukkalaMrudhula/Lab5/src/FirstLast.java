import java.util.Scanner;

//Write a Java Program to validate the full name of an employee.
//Create and throw a user defined exception if firstName and lastName is blank.
class NameException extends Exception
	{
	    public NameException(String s)
	    {
	        super(s);
	    }
	}
public class FirstLast {
	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		System.out.print("Enter ur first name: ");
		String firstName = s.nextLine();
		System.out.println("Enter ur last name: ");
		String lastName = s.nextLine();
		try
		{
			if(firstName.length()==0 &&  lastName.length()==0) 
			{
				throw new NameException("please provide info");
			}
			else
			{
				System.out.println("Successfully writtern");
			}
		}
		catch (NameException a)
		{
			System.out.println(a);
		}
		s.close();
	 }
}
