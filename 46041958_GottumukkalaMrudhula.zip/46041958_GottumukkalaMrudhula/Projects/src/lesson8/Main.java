package lesson8;

import java.util.HashMap;
import java.util.Map;

public class Main {
	public static void main(String[] args) {
		Employee e1=new Employee("M164");
		Employee e2=new Employee("M164");
		System.out.println(e1.equals(e2));
		
		Map<Employee,ScoreCard> employeeCard=new HashMap<Employee,ScoreCard>();
		employeeCard.put(e1,new ScoreCard());
		employeeCard.put(e2,new ScoreCard());
		
		System.out.println(employeeCard.size());
	}

}
