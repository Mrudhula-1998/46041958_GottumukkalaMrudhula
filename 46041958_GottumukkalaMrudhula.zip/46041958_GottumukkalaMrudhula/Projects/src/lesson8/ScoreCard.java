package lesson8;

public class ScoreCard {
	private int mainScore=100;
	public ScoreCard() {
		this.mainScore=mainScore;
	}
	public int getMainScore() {
		return mainScore;
	}
	public void setMainScore(int mainScore) {
		this.mainScore = mainScore;
	}
	

}
