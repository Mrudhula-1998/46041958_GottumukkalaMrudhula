package lesson8;

public class Employee {
	private String empNumber;
	public Employee(String empNumber) {
		this.empNumber=empNumber;
	}
	
	public String getEmpNumber() {
		return empNumber;
	}
	
	public void setEmpNumber(String empNumber) {
		this.empNumber = empNumber;
	}
	
	public boolean equals(Object o) {
		System.out.println("Equals ");
		if(o!=null && o instanceof Employee) {
			String empNumber=((Employee)o).getEmpNumber();
			if(empNumber!=null && empNumber.equals(this.getEmpNumber())) {
				return true;
			}
		}
		return false;
	}
	public int hashCode() {
		System.out.println("hash code");
		return this.empNumber.hashCode();
	}

}
