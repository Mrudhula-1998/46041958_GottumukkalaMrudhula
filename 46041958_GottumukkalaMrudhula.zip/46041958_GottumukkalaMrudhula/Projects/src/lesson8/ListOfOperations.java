package lesson8;

public class ListOfOperations {

}
