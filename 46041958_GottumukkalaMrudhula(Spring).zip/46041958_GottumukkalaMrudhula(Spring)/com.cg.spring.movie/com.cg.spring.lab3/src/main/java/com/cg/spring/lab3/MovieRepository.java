package com.cg.spring.lab3;

import org.springframework.data.repository.CrudRepository;

public interface MovieRepository extends CrudRepository<Movies, String> {

}
