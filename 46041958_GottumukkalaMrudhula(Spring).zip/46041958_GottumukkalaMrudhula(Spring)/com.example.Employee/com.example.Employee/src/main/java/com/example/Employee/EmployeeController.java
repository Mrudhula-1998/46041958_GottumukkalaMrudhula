package com.example.Employee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController 
{
	@Autowired
	EmployeeService employeeService;
	
	// insert employee
	@PostMapping("/Employee")
	private int AddEmployee(@RequestBody Employee employee)
	{
		employeeService.saveEmployee(employee);
		return employee.getEid();
	}
	
	
	//Update Employee
	@PutMapping("/Employee")
	private Employee Update(@RequestBody Employee employee)
	{
		employeeService.updateEmployee(employee);
		return employee;
	}
	
	
	//delete Employee
	@DeleteMapping("/Employee/{eid}")
	private void remove(@PathVariable("eid") int eid)
	{
		employeeService.delete(eid);
	}
	
	
	
	// retrieve employee by particular Id
	@GetMapping("/Employee/{eid}")
	private Employee getEmployee(@PathVariable("eid") int eid)
	{
		return employeeService.getEmployeeById(eid);
	}
	
	
	
	//Get all employees
		@GetMapping("/Employee")
		private List<Employee> getAllEmployee()
		{
			return employeeService.getAllEmployee();
		}
	
}
