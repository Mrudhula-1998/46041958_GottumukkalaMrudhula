package com.cg.Springlab2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class App 
{
	public static void main( String[] args )
    {
		ApplicationContext context = new AnnotationConfigApplicationContext(Config.class);
		SBU s=(SBU) context.getBean("sbu");
		Employee e = (Employee) context.getBean("emp");
		System.out.println(e);    			
    }
}


