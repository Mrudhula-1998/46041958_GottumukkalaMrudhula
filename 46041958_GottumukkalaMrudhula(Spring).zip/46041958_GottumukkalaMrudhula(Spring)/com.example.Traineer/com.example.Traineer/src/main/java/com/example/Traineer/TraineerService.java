package com.example.Traineer;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TraineerService {
	@Autowired
 	TraineerRepository traineerRepository;
 

 	public List<Traineer> getAllTraineer() {
       	List<Traineer> traineer = new ArrayList<Traineer>();
       traineerRepository.findAll().forEach(traineer1 -> traineer.add(traineer1));
       	return traineer;
 	}
 

 	public Traineer getTraineerById(int traineerId) {
       	return traineerRepository.findById(traineerId).get();
 	}

 	public void saveTraineer(Traineer traineer) {
       	traineerRepository.save(traineer);
 	}
 

 	public void delete(int traineerId) {
       	traineerRepository.deleteById(traineerId);
 	}
 
//updating a record
 	public void updateTraineer(Traineer traineer) {
       	traineerRepository.save(traineer);
 	}

}
